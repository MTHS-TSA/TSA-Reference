num = int(input())

def is_prime(num):
    for i in range(1, num):
        if num % i == 0 and i not in (1, num):
            return False
    return True



if is_prime(num):
    if num <= 1:
        print("Not a prime")
    else:
        print("Prime")
else:
    print("Not a prime")