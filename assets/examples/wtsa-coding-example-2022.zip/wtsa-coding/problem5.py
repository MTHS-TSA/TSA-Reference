ingredient_vol_weight = {
    "all-purpose flour": 142,
    "cake flour": 113,
    "granulated sugar": 198,
    "brown sugar": 198,
    "powdered sugar": 113
}

volume_to_ml = {
    "tsp": 5,
    "tbsp": 15,
    "c": 250,
    "pt": 500,
    "qt": 1000,
    "gal": 4000
}

def dim_analysis(measure, unit, multiplier, t, ingredient):
    if t == "v":
        amount = measure * volume_to_ml[unit] * multiplier
        if amount > 1000:
            return amount/1000, "L"
        else:
            return amount, "mL"
    elif t == "i":
        amount = measure * ingredient_vol_weight[ingredient] * multiplier
        if amount > 1000:
            return amount/1000, "kg"
        else:
            return amount, "g"
    else:
        if unit == "lb":
            return measure * 1000 / 28.349523125, "g"
        else:
            return measure / 28.349523125, "g"
        

instruction = input()
split_input = instruction.split()

num = float(split_input[0])
unit = split_input[1]
multiplier = float(split_input[-1][1:])
ingredient = " ".join(split_input[2:-1])

result = dim_analysis(num, unit, multiplier, 'v' if ingredient not in ingredient_vol_weight else "i", ingredient)

print(f"{round(result[0])} {result[1]} {ingredient}")