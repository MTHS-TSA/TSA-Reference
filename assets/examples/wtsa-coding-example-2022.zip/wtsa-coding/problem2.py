test_sentence = input().lower().replace(" ", "")
print(test_sentence)

alphabet = "abcdefghijklmnopqrstuvwxyz"

pangram = True
repeated = []
missing = []
for letter in alphabet:
    letter_count = test_sentence.count(letter)
    if letter_count < 1:
        pangram = False
        missing.append(letter)
    if letter_count > 1:
        repeated.append(letter)

if pangram:
    print("Pangram")
    print(" ".join(repeated))
else:
    print("Not a pangram")
    print(" ".join(missing))