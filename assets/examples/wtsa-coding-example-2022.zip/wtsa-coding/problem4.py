raw_intime = input()
raw_change = input() 

hour = int(raw_intime[0:2])
minute = int(raw_intime[3:5])
meridian = raw_intime[6:8]
if hour == 12:
    if meridian == "AM":
        meridian = "PM"
    else:
        meridian = "AM"

change_symbol = raw_change[0]
change_hr = int(raw_change[1:3])
change_min = int(raw_change[4:6])

def time_to_minutes(hours, minutes, meridian="AM"):
    total_minutes = (hours*60) + (minutes) + (0 if meridian == "AM" else (60*12))
    return total_minutes
def minutes_to_time(minutes):
    minutes += 60*24
    out_min = minutes % 60
    out_hr = (((minutes - out_min) / 60) + 24) % 24
    meridian = "AM"
    if out_hr >= 12:
        meridian = "PM"
        out_hr -= 12
    #HOUR TIME FORMATTING
    out_hr_str = str(int(out_hr))
    if len(out_hr_str) < 2:
        out_hr_str = "0" + out_hr_str
    #MINUTE TIME FORMATTING
    out_min_str = str(int(out_min))
    if len(out_min_str) < 2:
        out_min_str = "0" + out_min_str
    return f"{out_hr_str}:{out_min_str} {meridian}"

intime = time_to_minutes(hour, minute, meridian)
change_time = time_to_minutes(change_hr, change_min)

result_min = 0 
if change_symbol == "-":
    result_min = intime - change_time
else:
    result_min = intime + change_time
print(minutes_to_time(result_min))