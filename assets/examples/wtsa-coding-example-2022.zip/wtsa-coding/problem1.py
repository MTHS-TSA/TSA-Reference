num = input()

num_names = ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"]

print(" ".join([num_names[int(digit)] for digit in num]))