def fix67(length, array):
    # Errors if the given length is incorrect
    if length != len(array):
        print("Lengths don't match")
        return []
    
    # Stores where the last found 7 is so it isn't reused
    indexOf7 = 0

    # For each value in the array, if it's 6, find the next 7 that hasn't been used and swap it with the value in front of the 6
    for index, value in enumerate(array):
        if value == 6:
            
            # Finds the next 7
            searchIndex = indexOf7
            while array[searchIndex] != 7:
                searchIndex += 1

            # Swaps the two values
            array[searchIndex] = array[index+1]
            array[index + 1] = 7

            # Updates where the last 7 was
            indexOf7 = searchIndex + 1
    return array

# Runs only when not imported
# Fetches all the inputs and formats them into an array of integers
if __name__ == "__main__":
    length = int(input())
    array = input().split()
    for index in range(len(array)):
        array[index] = int(array[index])

    outArray = fix67(length, array)

    # Formats the array output
    outString = ""
    for value in outArray:
        outString += str(value) + " "
    print()
    print(outString)