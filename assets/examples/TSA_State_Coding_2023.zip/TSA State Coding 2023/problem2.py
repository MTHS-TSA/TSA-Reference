def leastCommonMultiple(integer1, integer2):
    # Finds the largest of the two numbers, as the LCM cannot be smaller than this
    divisible_number = max(integer1, integer2)

    # Counts up from there until a number is found which is divisible by both inputs
    while divisible_number % integer1 != 0 or divisible_number % integer2 != 0:
        divisible_number += 1
    return divisible_number

# Runs only when not imported
if __name__ == "__main__":
    integer1 = int(input("Please enter integer 1: "))
    integer2 = int(input("Please enter integer 2: "))
    print()
    print(f"Least common multiple: {leastCommonMultiple(integer1, integer2)}")
