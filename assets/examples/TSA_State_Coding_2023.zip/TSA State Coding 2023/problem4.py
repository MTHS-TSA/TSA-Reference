def binaryToDecimal(binary):
    # Finds the number by adding the value of each digit times two to the power of the place
    number = 0
    for place, bit in enumerate(binary):
        placeValue = int(bit) * 2 ** place
        number += placeValue
    return number

# Runs only when not imported
if __name__ == "__main__":
    binary = input("Enter the binary number: ")
    number = binaryToDecimal(binary)
    print(f"In decimal: {number}")