PI = 3.14159

def largestArea():
    numShapes = int(input())
    shapes = []
    # Gets each shape and converts it into a list of each of its properties
    for shapeNum in range(numShapes):
        shape = input()
        shape = shape.split(" ")
        shapes.append(shape)

    largestArea = 0
    largestIndex = 0

    # Finds the area of each shape and stores the largest one
    for index, shape in enumerate(shapes):
        area = 0
        if (shape[0] == "s"):
            area = squareArea(float(shape[1]))
        if (shape[0] == "t"):
            area = triangleArea(float(shape[1]), float(shape[2]))
        if (shape[0] == "c"):
            area = circleArea(float(shape[1]))
        if (shape[0] == "r"):
            area = rectangleArea(float(shape[1]), float(shape[2]))
        if area > largestArea:
            largestArea = area
            largestIndex = index
    
    # Returns a formatted string of the largest shape
    largestShape = shapes[largestIndex]
    return f"{largestShape[-1]} {largestShape[0]} {round(largestArea, 3)}"

# Helper functions for finding the area of each kind of shape
def squareArea(sideLength):
    return sideLength ** 2

def triangleArea(base, height):
    return (base*height) / 2

def circleArea(radius):
    return PI * (radius ** 2)

def rectangleArea(width, height):
    return width * height

if __name__ == "__main__":
    print()
    print(largestArea())