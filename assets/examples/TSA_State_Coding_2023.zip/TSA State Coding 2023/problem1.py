def capitalGains():
    numYears = int(input("Over how many years did the customer purchase Stock X: "))
    print()
    
    # Creates a 2D array where each row is a year
    # The first collumn is the number of shares bought that year and the second is the price that year
    portfolio = []
    for year in range(numYears):
        shares = int(input("How many units did the customer purchase in year 1?: "))
        price = float(input("At what price per share?: "))
        portfolio.append([shares, price])
        print()

    stocksSold = int(input("How many units did the customer sell?: "))
    sellPrice = float(input("At what price per share?: "))
    print()

    # Sets the capital gain to the amount gained for the sale, then subtracts the price of each stock sold at its time of purchase
    capitalGain = sellPrice * stocksSold
    year = 0
    for stock in range(stocksSold):
        if (portfolio[year][0] == 0):
            year += 1
        capitalGain -= portfolio[year][1]
        portfolio[year][0] -= 1
    return capitalGain

# Runs only when not imported
if __name__ == "__main__":
    gains = round(capitalGains(), 2)
    if (gains==int(gains)):
        gains = int(gains)
    print(f"The customer's total captial gain is: {gains} dollars")