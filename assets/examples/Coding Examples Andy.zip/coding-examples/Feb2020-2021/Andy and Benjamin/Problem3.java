import java.util.*;
import java.io.*;

/**
 * This class takes a number that represents the number of socks a person has and print to the console the combination of pairs that person can make.
 *
 * @author Andy Chen
 * @author Benjamin Hoang
 */
public class Problem3 {
    /**
     * BufferedReader is a class that can be connected to a reader class that reads from the console
     *
     * @see Scanner is an alternative way to recieve input but slightly slower
     */
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    /**
     * PrintWriter is a class that prints to the console.
     * The second parameter is set to true to indicate that it will auto-flush. Auto-flushing will always free the data stored in its stream into the console after certain methods without have to call the .flush() method
     *
     * @see System An alternative to printing to console is System.out.println(). This way is less efficient as it deals with bytes instead of characters
     */
    static PrintWriter pw = new PrintWriter(System.out, true);

    /**
     * This is the main method.
     * It will run the method called run() which contains most of the code for solving the problem.
     * The PrintWriter and BufferReader will be closed after everything is done running.
     * Everything is wrapped in a try catch to catch exceptions throw by BufferedReader and PrintWriter methods, and to catch other errors.
     *
     * @param args
     */
    public static void main(String[] args) {
        try{
            run();
            pw.close();
            br.close();
        }catch(IOException IOE){
            pw.println("Error with I/O");
        }catch(NumberFormatException NFE){
            pw.println("Invalid Input");
        }catch(Exception E){
            pw.println("Something went wrong.");
        }
    }

    /**
     * This run() method does all the printing and reading. The code that does the combination calculation is in another method.
     *
     * @throws IOException IOException is to be caught by the main method. This is thrown by the I/O classes and this exception must be caught in order to use methods from those classes.
     */
    public static void run() throws IOException {
        pw.print("Enter the number of socks: ");
        pw.flush();
        int socks = Integer.parseInt(br.readLine());

        if(socks < 2){
            pw.print("Invalid Input");
            return;
        }

        int pairs = combinationPair(socks);
        pw.print("Number of different pairs: " + pairs);
    }

    /**
     * This method does the math using a simplified form of the combinations formula base on the constant variable already provided.
     * One such variable is 2, which allowed the the formula to be simplified into the form n * (n-1) / 2;
     * @param socks Number of socks.
     * @return The number of combinations.
     */
    public static int combinationPair(int socks){
        int pairs = (socks * (socks -1 )) / 2;
        return pairs;
    }
}
