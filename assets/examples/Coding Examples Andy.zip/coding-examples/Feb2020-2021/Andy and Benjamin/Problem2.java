import java.util.*;
import java.io.*;

/**
 * This class takes three numbers from console and prints if the numbers are pythagorean triples to the console.
 *
 * @author Andy Chen
 * @author Benjamin Hoang
 */
public class Problem2 {
    /**
     * BufferedReader is a class that can be connected to a reader class that reads from the console
     *
     * @see Scanner is an alternative way to recieve input but slightly slower
     */
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    /**
     * PrintWriter is a class that prints to the console.
     * The second parameter is set to true to indicate that it will auto-flush. Auto-flushing will always free the data stored in its stream into the console after certain methods without have to call the .flush() method
     *
     * @see System An alternative to printing to console is System.out.println(). This way is less efficient as it deals with bytes instead of characters
     */
    static PrintWriter pw = new PrintWriter(System.out, true);

    /**
     * This is the main method.
     * It will run the method called run() which contains most of the code for solving the problem.
     * The PrintWriter and BufferReader will be closed after everything is done running.
     * Everything is wrapped in a try catch to catch exceptions throw by BufferedReader and PrintWriter methods, and to catch other errors.
     *
     * @param args
     */
    public static void main(String[] args) {
        try{
            run();
            pw.close();
            br.close();
        }catch(IOException IOE){
            pw.println("Error with I/O");
        }catch(NumberFormatException NFE){
            pw.println("Invalid Input");
        }catch(Exception E){
            pw.println("Something went wrong.");
        }
    }

    /**
     * This run() method does all the printing and reading. The code that does the checking is in another method.
     *
     * @throws IOException IOException is to be caught by the main method. This is thrown by the I/O classes and this exception must be caught in order to use methods from those classes.
     */
    public static void run() throws IOException {
        pw.print("Enter a: ");
        pw.flush();
        int a = Integer.parseInt(br.readLine());

        pw.print("Enter b: ");
        pw.flush();
        int b = Integer.parseInt(br.readLine());

        pw.print("Enter c: ");
        pw.flush();
        int c = Integer.parseInt(br.readLine());

        boolean yes = checkPythagoreanTriples(a, b, c);
        if(yes == true){
            pw.println("A Pythagorean Triple");
        }else{
            pw.println("Not a Pythagorean Triple");
        }
    }

    /**
     * This method does checks if the three numbers are pythagorean triples
     * @param a First number
     * @param b Second number
     * @param c Third number
     * @return Return if the three numbers are pythagorean triples
     */
    public static boolean checkPythagoreanTriples(int a, int b, int c){
        if(0 >= a || a >= b || b >= c) {
            return false;
        }
        if(a*a + b*b == c*c){
            return true;
        }
        return false;
    }
}
