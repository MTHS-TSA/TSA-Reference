import java.util.*;
import java.io.*;

/**
 * This class calculates the probability of n number of darts hitting a specific color of a dart board (n is a number between 1 and 4 inclusive)
 *
 * @author Andy Chen
 * @author Benjamin Hoang
 */
public class Problem5 {
    /**
     * BufferedReader is a class that can be connected to a reader class that reads from the console
     *
     * @see Scanner is an alternative way to recieve input but slightly slower
     */
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    /**
     * PrintWriter is a class that prints to the console.
     * The second parameter is set to true to indicate that it will auto-flush. Auto-flushing will always free the data stored in its stream into the console after certain methods without have to call the .flush() method
     *
     * @see System An alternative to printing to console is System.out.println(). This way is less efficient as it deals with bytes instead of characters
     */
    static PrintWriter pw = new PrintWriter(System.out, true);

    /**
     * Constant double representing the ratio of red to all colors on the dart board
     */
    static final double RED = 16/24.0;
    /**
     * Constant double representing the ratio of green to all colors on the dart board
     */
    static final double GREEN = 4/24.0;
    /**
     * Constant double representing the ratio of blue to all colors on the dart board
     */
    static final double BLUE = 4/24.0;
    /**
     * This is the main method.
     * It will run the method called run() which contains most of the code for solving the problem.
     * The PrintWriter and BufferReader will be closed after everything is done running.
     * Everything is wrapped in a try catch to catch exceptions throw by BufferedReader and PrintWriter methods, and to catch other errors.
     *
     * @param args
     */
    public static void main(String[] args) {
        try{
            run();
            pw.close();
            br.close();
        }catch(IOException IOE){
            pw.println("Error with I/O");
        }catch(NumberFormatException NFE){
            pw.println("Invalid Input");
        }catch(IllegalArgumentException IAE){
            pw.println(IAE.getMessage());
        }catch(Exception E){
            pw.println("Something went wrong.");
        }
    }

    /**
     * This run() method does all the printing and reading. The code that does the probability calculation is in another method.
     *
     * @throws IOException IOException is to be caught by the main method. This is thrown by the I/O classes and this exception must be caught in order to use methods from those classes.
     */
    public static void run() throws IOException {
        pw.print("Enter the number of darts thrown: ");
        pw.flush();
        int darts = Integer.parseInt(br.readLine());

        if(darts<=0){
            pw.println("Number of darts thrown cannot be negative or 0.");
            return;
        }

        pw.print("Enter the color: ");
        pw.flush();
        String color = br.readLine().trim();

        pw.print("Enter ONLY or NO: ");
        pw.flush();
        String OnlyNo = br.readLine().trim();

        double probability = dartsProbability(darts, color, OnlyNo);
        pw.printf("The probability that %s %s rectangles are hit in %d throws is: %.2f%%", OnlyNo, color, darts, probability*100);
    }

    /**
     * This class calculates the probability of a set number of darts hitting only or no areas of the dartboard of a given color
     * The calculation is done using the binomial probability formula. The formula used is simplified because the expression for calculating the amount of combinations always evaluate to 1 when given either ONLY or NO.
     * @param darts Number of darts
     * @param color The specified color
     * @param OnlyNo Specification of dart hitting only or no areas of the board of the color
     * @return The probability
     * @throws IllegalArgumentException This is thrown in case if the string color or onlyno is invalid
     */
    public static double dartsProbability(int darts, String color, String OnlyNo) throws IllegalArgumentException{
        int success = 0;
        int lose = 0;

        switch(OnlyNo){
            case "ONLY":
                success = darts;
                break;
            case "NO":
                lose = darts;
                break;
            default:
                throw new IllegalArgumentException("Invalid condition (input ONLY or NO)");
        }

        double colorProb = 0.0;
        switch(color){
            case "Red":
                colorProb = RED;
                break;
            case "Blue":
                colorProb = BLUE;
                break;
            case "Green":
                colorProb = GREEN;
                break;
            default:
                throw new IllegalArgumentException("Invalid color input (Red, Green, or Blue)");
        }

        double prob = Math.pow(colorProb, success) * Math.pow(1.0 - colorProb, lose);

        return prob;
    }
}
