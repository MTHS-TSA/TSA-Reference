import java.util.*;
import java.io.*;

public class Problem4 {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    static PrintWriter pw = new PrintWriter(System.out,true);

    public static void main(String[] args){
        try{
            run();
            pw.close();
            br.close();
        }catch(IOException IOE){
            pw.println("Error with I/O");
        }catch(NumberFormatException NFE){
            pw.println("Invalid Input");
        }catch(Exception E){
            pw.println("Something went wrong.");
        }
    }

    public static void run() throws IOException{
      LinkedHashMap<String, Integer> prez = new LinkedHashMap<>();
      LinkedHashMap<String, Integer> vp = new LinkedHashMap<>(); 
      LinkedHashMap<String, Integer> secr = new LinkedHashMap<>();
      LinkedHashMap<String, Integer> tres = new LinkedHashMap<>();
      LinkedHashMap<String, Integer> rep = new LinkedHashMap<>();
      LinkedHashMap<String, Integer> serg = new LinkedHashMap<>();
      //linkedhashmap keeps track of insertion order
      //hashmaps for keeping track of candidates for each category and their votes
    
      int ballots = Integer.parseInt(br.readLine()); 
      for(int i = 0;i<ballots;i++){ //for each ballot, do this
        String[] s = br.readLine().trim().split(" "); //store names in an array
        if(s.length!=6){
          throw new NumberFormatException();
        } //make sure the ballot is valid

        //for each position, check if candidate already has been voted for.
        //if the candidate has been voted for, increase their vote countVotes
        //else, add their name and starting vote count(1) to the linkedhashmap
        if(prez.containsKey(s[0])){
          prez.put(s[0], prez.get(s[0])+1);
        }else{
          prez.put(s[0], 1);
        }
        if(vp.containsKey(s[1])){
          vp.put(s[1], vp.get(s[1])+1);
        }else{
          vp.put(s[1], 1);
        }
        if(secr.containsKey(s[2])){
          secr.put(s[2], secr.get(s[2]) + 1);
        }else{
          secr.put(s[2], 1);
        }
        if(tres.containsKey(s[3])){
          tres.put(s[3], tres.get(s[3]) + 1);
        }else{
          tres.put(s[3], 1);
        }
        if(rep.containsKey(s[4])){
          rep.put(s[4], rep.get(s[4]) + 1);
        }else{
          rep.put(s[4], 1);
        }
        if(serg.containsKey(s[5])){
          serg.put(s[5], serg.get(s[5]) + 1);
        }else{
          serg.put(s[5], 1);
        }  
      }//end ballot loop

      //perform the countvote method for each category
      countVotes(prez, "President:");
      countVotes(vp, "Vice President:");
      countVotes(secr, "Secretary:");
      countVotes(tres, "Treasurer");
      countVotes(rep, "Reporter:");
      countVotes(serg, "Sergeant-at-Arms:");
    }

    public static void countVotes(LinkedHashMap<String, Integer> hm, String str){ //linkedhashmap and str message to print
      StringBuilder sb = new StringBuilder(); //stringbuilder will keep track of names
      int biggest = 0; //keep track of the largest vote count
      boolean tie = false; //check if there is a tie
      for(String s:hm.keySet()){ //for each name(key) in the linkedhashmap
        if((int)hm.get(s)>biggest){ //if vote is greater
          sb = new StringBuilder(); //reset names
          sb.append(" ");
          sb.append(s); //add the new name
          biggest = hm.get(s); //update biggest
          tie = false; //reset tie
        }else if(hm.get(s)==biggest){ //check for tie
          sb.append(" ");
          sb.append(s); //add name
          tie = true; //update tie
        }
      }
      pw.print(str); //print position name
      if(tie){ //print tie if there is one
        pw.print(" -tie-");
      }
      pw.print(sb.toString()); //print names
      pw.print(", ");
      pw.println(biggest); //print vote count
    }
}