import java.util.*;
import java.io.*;

public class Problem2 {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    static PrintWriter pw = new PrintWriter(System.out,true);

    public static void main(String[] args){
        try{
            run();
            pw.close();
            br.close();
        }catch(IOException IOE){
            pw.println("Error with I/O");
        }catch(NumberFormatException NFE){
            pw.println("Invalid Input");
        }catch(Exception E){
            pw.println("Something went wrong.");
        }
    }
    /*This method will replace a substring inside a main string with a new string
    */
    public static void run() throws IOException{
      String text = br.readLine(); //original string
      String replacing = br.readLine(); //string that we want replaced
      String newtext = br.readLine();//the new string we want to replace it
      pw.println(text.replaceAll(replacing,newtext));//use replace method and print to console
    }
}