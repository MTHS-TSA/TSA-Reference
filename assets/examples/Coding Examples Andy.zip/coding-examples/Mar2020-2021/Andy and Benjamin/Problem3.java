import java.util.*;
import java.io.*;

public class Problem3 {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    static PrintWriter pw = new PrintWriter(System.out,true);

    public static void main(String[] args){
        try{
            run();
            pw.close();
            br.close();
        }catch(IOException IOE){
            pw.println("Error with I/O");
        }catch(NumberFormatException NFE){
            pw.println("Invalid Input");
        }catch(Exception E){
            pw.println("Something went wrong.");
        }
    }
    /*This method will determine if we need to find the volume of a sphere or the radius, and will use the necessary equation to do so
    */
    public static void run() throws IOException{
      String s = br.readLine();
      if(s.equals("volume")){//if we are given volume
        double volume = Double.parseDouble(br.readLine());
        double r = (3 * volume)/(4*3.14159);//equation to find radius
        r = Math.pow(r,1/3.0);//and then raise to the power of 1/3
        pw.printf("radius = %.1f%n", r);//round to nearest tenth and print
        pw.flush();
      }
      if(s.equals("radius")){//if we are given radius
        double radius = Double.parseDouble(br.readLine());
        double v = (4/3.0) * 3.14159 * Math.pow(radius,3);//equation to find volume
        pw.printf("volume = %.1f%n", v);//round to nearest tenth and print
        pw.flush();
      }
    }
}