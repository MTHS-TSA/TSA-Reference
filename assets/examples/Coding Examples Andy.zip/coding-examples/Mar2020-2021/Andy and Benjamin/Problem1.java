import java.util.*;
import java.io.*;

public class Problem1 {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    static PrintWriter pw = new PrintWriter(System.out,true);

    public static void main(String[] args){
        try{
            run();
            pw.close();
            br.close();
        }catch(IOException IOE){
            pw.println("Error with I/O");
        }catch(NumberFormatException NFE){
            pw.println("Invalid Input");
        }catch(Exception E){
            pw.println("Something went wrong.");
        }
    }
    /*This method will take in two strings of input and search through each string and see if there are any common characters.
    */
    public static void run() throws IOException{
      //two strings from the input
      String a = br.readLine();
      String b = br.readLine();
      //two character frequency arrays that cover the ascii table, one array for each string
      int[] freqa = new int[256];
      int[] freqb = new int[256];

      //go through each character of both string and increment the //correct position on the frequency array
      for(char c : a.toCharArray()){
        freqa[c]++;
      }
      for(char c : b.toCharArray()){
        freqb[c]++;
      }

      boolean yes = false;
      //compare the two frequency arrays, if there is a common character then print out YES, if not then print out NO
      for(int i = 0; i<freqa.length; i++){
        if(freqa[i] > 0 && freqb[i] > 0){
          pw.println("YES"); 
          yes = true;
          break;
        }
      }
      if(yes == false){
        pw.println("NO");
      }
    }
}