import java.util.*;
import java.io.*;

public class Problem5 {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    static PrintWriter pw = new PrintWriter(System.out,true);

    public static void main(String[] args){
        try{
            run();
            pw.close();
            br.close();
        }catch(IOException IOE){
            pw.println("Error with I/O");
        }catch(NumberFormatException NFE){
            pw.println("Invalid Input");
        }catch(NullPointerException NE){
            pw.println("Invalid Starting Position Input");
        }catch(Exception E){
          E.printStackTrace();
            pw.println("Something went wrong.");
        }
    }

    public static void run() throws IOException{
      int columns = Integer.parseInt(br.readLine());
      int rows = Integer.parseInt(br.readLine()); //store columns and rows

      String s = br.readLine();
      int startX = s.charAt(0) - 'A' + 1; //convert character to an integer value
      int startY = Character.getNumericValue(s.charAt(1));

      String commands = br.readLine();
      for(char c:commands.toCharArray()){ //for each move command
        switch(c){
          case 'N':
            startY--;
            break;
          case 'S':
            startY++;
            break;
          case 'E':
            startX++;
            break;
          case 'W':
            startX--;
            break;
        }
        if(startX<=0||startY<=0||startX>columns||startY>rows){
          //check if the robot has at any point moved beyond the confines of the grid
          pw.println("Out of bounds.");
          return;
        }
      }
      char col = (char)(startX - 1 + 65); //convert column to char value
      pw.print(col);
      pw.println(startY);
    }
}