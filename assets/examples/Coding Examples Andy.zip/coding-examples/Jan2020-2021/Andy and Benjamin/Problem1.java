import java.util.*;
import java.io.*;

/**
 * This class is a command-line program that takes a decimal number input and outputs a hexadecimal number.
 * @author Andy Chen, Benjamin Hoang
 */
public class Problem1 {
    /**
     * BufferedReader is a class that can be connected to a reader class that reads from the console
     * @see Scanner is an alternative way to recieve input but slightly slower
     */
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    /**
     * PrintWriter is a class that prints to the console.
     * The second parameter is set to true to indicate that it will auto-flush. Auto-flushing will always free the data stored in its stream into the console after certain methods without have to call the .flush() method
     * @see System An alternative to printing to console is System.out.println(). This way is less efficient as it deals with bytes instead of characters
     */
    static PrintWriter pw = new PrintWriter(System.out, true);
    /**
     *char array of hexadecimal digits for later reference
     */
    static final char[] hexArr = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

    /**
     * main method
     * It will run the method called run() which contains most of the code for logically solving the problem.
     * The PrintWriter and BufferReader will be closed after everything is done running.
     * Everything is wrapped in a try catch to catch exceptions throw by BufferedReader and PrintWriter methods, and to catch other errors.
     * @param args
     */
    public static void main(String[] args) {
        try {
            run();
            pw.close();
            br.close();
        } catch (IOException x) {
            pw.println("error with input/output");
        }catch(NumberFormatException x){
            pw.println("invalid input");
        }catch(Exception x){
            pw.println("something went wrong");
        }
    }

    /**
     * This run() method does all the printing and reading. The code that does the conversion is in another method
     * @throws IOException IOException is to be caught by the main method.
     */
    public static void run() throws IOException {
        pw.print("In decimal: ");
        pw.flush(); //auto-flush doesn't happen after print() so I have to call this
        int input = Integer.parseInt(br.readLine());
        pw.print("Enter hexadecimal number: ");
        pw.println(toHex2(input));
    }

    /**
     * This method calculates the hexadecimal number mathematically
     * @param num the numeric input to be converted
     * @return a string representation of the hexadecimal number is returned
     */
    public static String toHex2(int num){
        StringBuilder sb = new StringBuilder();

        if(num<0){ //in case the number is negative, do this
            sb.append("-");
            num = num*-1;
        }
        sb.append("0x");

        int valToPow = 0;
        int digits = 0;
        while(num>=valToPow){
            valToPow = (int)Math.pow(16,++digits);
        }//records the amount of digits the hexadecimal number will have by using base exponentiation
        //each place can be represented by i*16^e where i is the value at the digit and e is the exponent

        while(digits>0){//calculate all the digits and store it in the StringBuilder
            int base = (int)Math.pow(16,digits-1);//this stores the base. the exponent is one-less than the digits place
            int index = (int)num/base; //the value at the current digits place. It's named index because it will be used to refer to hexArr that was created earlier
            num -= base*index; //update num for the next iteration
            sb.append(hexArr[index]); // add to stringbuilder
            digits--; //update the digits place
        }
        return sb.toString();
    }

    /**
     * This method is unused by the program
     * This method contains a built-in java method that does the conversion (.toString())
     * @param num the numeric input to be converted
     * @return a string representation of the hexadecimal number is returned
     */
    public static String toHex1(int num){
        StringBuilder sb = new StringBuilder();
        sb.append("0x");
        sb.append(Integer.toString(num, 16).toUpperCase());
        return sb.toString();
    }
}
