import java.util.*;
import java.io.*;

/**
 * This program finds the first longest common substring of two strings
 * @author Andy Chen, Benjamin Hoang
 */
public class Problem2 {
    /**
     * BufferedReader is a class that can be connected to a reader class that reads from the console
     * @see Scanner is an alternative way to recieve input but slightly slower
     */
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    /**
     * PrintWriter is a class that prints to the console.
     * The second parameter is set to true to indicate that it will auto-flush. Auto-flushing will always free the data stored in its stream into the console after certain methods without have to call the .flush() method
     * @see System An alternative to printing to console is System.out.println(). This way is less efficient as it deals with bytes instead of characters
     */
    static PrintWriter pw = new PrintWriter(System.out, true);

    /**
     * main method
     * It will run the method called run() which contains most of the code for logically solving the problem.
     * The PrintWriter and BufferReader will be closed after everything is done running.
     * Everything is wrapped in a try catch to catch exceptions throw by BufferedReader and PrintWriter methods, and to catch other errors.
     * @param args
     */
    public static void main(String[] args) {
        try{
            run();
            br.close();
            pw.close();
        }catch(IOException x){
            pw.println("error with I/O stream");
        }catch(Exception x){
            pw.println("something went wrong");
        }
    }

    /**
     * This run() method does all the printing and reading. The code that does the conversion is in another method
     * @throws IOException IOException is to be caught by the main method.
     */
    public static void run() throws IOException {
        String s1 = br.readLine();
        String s2 = br.readLine();
        pw.println();
        pw.println(solve(s1,s2));
    }

    /**
     * This method contains the code to find the substring.
     * The basic idea of how the code works is that for each character in the first string, it is compared to the each character of the second string.
     * If a common character is found, go through another loop to find if there are more consecutive common characters.
     * Once that loop finishes either by reaching the end or reading different characters, compare it to the current biggest string and update it if it is larger.
     * @param s1 The first string to be compared
     * @param s2 The second string to be compared
     * @return Returns the first largest substring that both strings contain
     */
    public static String solve(String s1, String s2){
        if(s1.length()==0||s2.length()==0) return ""; //if any lengths are zero, return an "empty" string

        String biggest = "";
        char[] s1Arr = s1.toCharArray();
        char[] s2Arr = s2.toCharArray();//arrays to work with the characters faster
        StringBuilder sb = new StringBuilder();

        for(int i = 0; i < s1Arr.length; i++){ //for each char in first string
            for(int j = 0;j < s2Arr.length; j++){ //for each char in second string
                char c1 = s1Arr[i];
                char c2 = s2Arr[j]; //get the current chars

                if(c1==c2){
                    int c1_in = i;
                    int c2_in = j; //variables to store the index value while moving through the string to check consecutive common characters

                    while(c1_in < s1Arr.length && c2_in < s2Arr.length){ //this conditional makes sure the indexes doesn't go out of bounds
                        c1 = s1Arr[c1_in];
                        c2 = s2Arr[c2_in];

                        if(c1==c2){
                            sb.append(c1);
                            c1_in++;
                            c2_in++;
                        }else{
                            break;
                        }
                    }

                    String s = sb.toString();
                    if(s.length()>biggest.length()){
                        biggest = s;
                    }//check if new string is bigger than current biggest
                    sb = new StringBuilder(); //reset StringBuilder
                }
            }
        }
        return biggest;
    }
}
