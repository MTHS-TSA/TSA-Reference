import java.util.*;
import java.io.*;

/**
 * This program prints all k-length combination of characters inputted through the console. k is also inputted through console.
 * @author Andy Chen, Benjamin Hoang
 */
public class Problem3 {
    /**
     * BufferedReader is a class that can be connected to a reader class that reads from the console
     * @see Scanner is an alternative way to recieve input but slightly slower
     */
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    /**
     * PrintWriter is a class that prints to the console.
     * The second parameter is set to true to indicate that it will auto-flush. Auto-flushing will always free the data stored in its stream into the console after certain methods without have to call the .flush() method
     * @see System An alternative to printing to console is System.out.println(). This way is less efficient as it deals with bytes instead of characters
     */
    static PrintWriter pw = new PrintWriter(System.out, true);

    /**
     * main method
     * It will run the method called run() which contains most of the code for logically solving the problem.
     * The PrintWriter and BufferReader will be closed after everything is done running.
     * Everything is wrapped in a try catch to catch exceptions throw by BufferedReader and PrintWriter methods, and to catch other errors.
     * @param args
     */
    public static void main(String[] args) {
        try{
            run();
            br.close();
            pw.close();
        }catch(IOException x){
            pw.println("I/O error");
        }catch(NumberFormatException x){
            pw.println("invalid input");
        }
    }

    /**
     * This method does takes the input and input them as arguments into the method that will do all the solving.
     * This method will also handle some invalid inputs.
     * @throws IOException IOException is to be caught by the main method.
     * @throws NumberFormatException This exception is to be caught by the main method in case k is an invalid input
     */
    public static void run() throws IOException, NumberFormatException{
        pw.print("Set: ");
        pw.flush();
        String s = br.readLine(); //store the input into a string

        if(s.length()==0){ //if the string input is blank, exit this method. After this method is exited, the program will end without running the method that solves the problem
            pw.println("invalid set");
            return; //if this wasn't caught, the program will recur indefinitely
        }
        String[] set = s.split(" "); //create an array of "characters"(assuming that only characters are inputted and separated from each other by single spaces)

        pw.print("k: ");
        pw.flush();
        int k = Integer.parseInt(br.readLine()); //input for k

        recurStr(set, "", k); //run the method that does the solving. It is given a set, a blank string as a base, and k.
    }

    /**
     * The main idea of this method is that it will recur until the length of string s is equal to k.
     * At each step, append one character(since there are multiple characters to append, the recursion will branch out).
     * @param set This set contains the characters to be used in the combination
     * @param s This string is to be used as reference throughout the recursion
     * @param length This is the goal length of s.
     */
    public static void recurStr(String[] set, String s, int length){
        if(s.length()>=length){
            pw.println(s);
            return;
        } //return when the length of s is equal to(or greater than if the "character" size is greater than 1) k.

        for(String str: set){ //for each character in the set
            StringBuilder t = new StringBuilder(s);
            t.append(str); //creates a StringBuilder to append to s

            recurStr(set, t.toString(),length); //run the method again but with the updated string
        }
        return; //exits the method after all the recursion is done
    }
}
