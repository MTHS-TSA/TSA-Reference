import java.util.Scanner;
import java.util.stream.*;
//everything explained in text file
public class Problem3 {
    Scanner scanner = new Scanner(System.in);
    String missing = "Vowel(s) not present:";

    int total = 0;
    int a, e, i, o, u = 0;
    public static void  main(String[] args){
        Main vowelCheck = new Main();
        vowelCheck.go();

    }
    public void go(){
        this.checkVowels();
        this.end();
    }

    public String getMessage(){
        System.out.print("Message: ");
        String message = scanner.nextLine();
        message = message.strip().toLowerCase();
        return message;
    }

    public void checkVowels(){
        String message = this.getMessage();
        String changedMessage = message;

        a = changedMessage.replaceAll("[^a]","").length();
        if(a==0){
            missing += " a";
        }
        changedMessage = message;

        e = changedMessage.replaceAll("[^e]","").length();
        if(e==0){
            missing +=" e";
        }
        changedMessage =message;

        i = changedMessage.replaceAll("[^i]","").length();
        if(i==0){
            missing += " i";
        }
        changedMessage = message;

        o = changedMessage.replaceAll("[^o]","").length();
        if(o==0){
            missing += " o";
        }
        changedMessage = message;

        u = changedMessage.replaceAll("[^u]","").length();
        if(u==0){
            missing += " u";
        }
        changedMessage = message;
    }
    public void end(){
        System.out.println("Number of vowels: " + ( a + e + i + o + u ));
        if(!missing.equals("Vowel(s) not present:")){
            System.out.println(missing);
        }
    }
}
