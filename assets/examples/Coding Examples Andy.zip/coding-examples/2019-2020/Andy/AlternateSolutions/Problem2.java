import java.util.Scanner;

public class Problem2 {
    Scanner scanner = new Scanner(System.in);
    double balance;
    public static void main(String[] ars){
        Main bank = new Main();
        bank.go();
    }//closes main
    public boolean makeTransaction(){
        System.out.print("Transaction: ");
        double transaction = Double.parseDouble(scanner.nextLine());
        balance += transaction;
        if(transaction==0){
            return true;
        }else {
            return false;

        }
    }//closes makeTransaction
    public void check() {
        if (balance < 0) {
            System.out.println("ALERT: Your account has a negative balance of $" + String.format("%.2f", balance) + "!");
        }else if(balance<250){
            System.out.println("WARNING: Your balance of $" + String.format("%.2f", balance) + " is less than $250.");
        }
    }//closes check
    public void go(){
        if(this.makeTransaction()==false){
            this.check();
            this.go(); // recursion, check in text file for details
        }else{
            System.out.println("Your final balance is $" + String.format("%.2f", balance) + ".");
        }
    }//closes go
}


