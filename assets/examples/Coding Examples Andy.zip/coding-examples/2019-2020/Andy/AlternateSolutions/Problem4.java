
import java.util.Scanner;
import java.util.HashMap;

public class Problem4 {

    String bestStudents = "";
    int mostAttend = 0;
    HashMap<String, Integer> attendance = new HashMap<String, Integer>();
    Scanner scanner = new Scanner(System.in);

    public int getWeekInput(){
        System.out.print("Number of Weeks: ");
        String weeks = scanner.nextLine();
        return Integer.parseInt(weeks.strip().toLowerCase());
    }

    public String[] getStudents(int n){
        System.out.print("Week " + n + " Attendance: ");
        String students = scanner.nextLine();
        return students.split(" ");
    }

    public void weekLoop(){
        int weekTotal = this.getWeekInput()+1;
        for(int i = 1; i < weekTotal; i++){
            String[] currentStudents = this.getStudents(i);
            for(String student:currentStudents){
                this.check(student);
            }
            //code to help find if code works or not
            //System.out.println(java.util.Arrays.toString(currentStudents));

            /*    for(java.util.Map.Entry<String, Integer> pair:attendance.entrySet()){
                    System.out.println(pair.getKey() + " " + pair.getValue());
                }
	    */	
        }

    }
    public void check(String compare){
        int i = 1;
        if(attendance.containsKey(compare)) {
            i = attendance.get(compare) +1;
            attendance.remove(compare);
        }
        attendance.put(compare,i);
        this.setEndMessage(compare,i);
    }
    public void setEndMessage(String best, int most){
        if(most>mostAttend){
            mostAttend = most;
            bestStudents = "";
            bestStudents += (" " + best);
        }else if(most==mostAttend){
            bestStudents +=(" " + best);
        }
    }
    public void go(){
        this.weekLoop();
        this.end();
    }
    public void end(){
        System.out.println("Best Attendance:" + bestStudents + ", " + mostAttend + " meetings");
    }
    public static void main(String[] args){
        Main main = new Main();
       main.go();
    }
}
