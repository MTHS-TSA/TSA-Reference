
import java.util.Scanner; //import

public class Problem1 {

    int firstNum;
    int secNum;
    String op;
    Scanner scanner = new Scanner(System.in); //variables

    public static void main(String[] args){
        new SimpleCalc().go();
    } //closes main

    public void go(){
        this.getInput();
        this.checkAndReturn();
    } //closes go

    public void getInput(){
        System.out.print("1st Number: ");
        firstNum = Integer.parseInt(scanner.nextLine());
        System.out.print("2nd Number: ");
        secNum = Integer.parseInt(scanner.nextLine());
        System.out.print("Operator: ");
        op = scanner.nextLine().strip();
    } //close getInput

    public void checkAndReturn(){
        if(op.equals("/")&&secNum==0){
            System.out.println("Error: Division by Zero");
        }else{
            switch(op){
                case "+":
                    this.add(firstNum,secNum);
                    break;
                case "-":
                    this.subtract(firstNum, secNum);
                    break;
                case "*":
                    this.multiply(firstNum, secNum);
                    break;
                case "/":
                    this.divide(firstNum, secNum);
                    break;
            }//closes switch
        }//closes if else
        scanner.close();
    }//closes checkAndReturn

    public void add(int f, int s){
        int total = f+s;
        this.printFinal(f,s,total, '+');
    }//closes add

    public void subtract(int f, int s){
        int total = f-s;
        this.printFinal(f,s,total, '-');
    }//closes subtract

    public void multiply(int f, int s){
        int total = f*s;
        this.printFinal(f,s,total,'*');
    }//closes multiply

    public void divide(int f, int s){
        int total = f/s;
        this.printFinal(f,s,total,'/');
    }//closes divide

    public void printFinal(int f, int s, int total, char op){
        System.out.println(f + " " + op + " " + s + " = " + total);
    }//closes printFinal

}//closes class
