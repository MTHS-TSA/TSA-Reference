import java.util.Scanner; //imports a scanner to take user input

public class Problem1 {
    public static void main(String[] args){

        Scanner input  = new Scanner(System.in);//new scanner object
        int total = 0; //total of both numbers
        boolean error = false; //boolean for whether division by zero is happening or not

        System.out.print("1st Number: ");
        int numberOne = Integer.parseInt(input.next());//gets and stores first number

        System.out.print("2nd Number: ");
        int numberTwo = Integer.parseInt(input.next());//gets and stores second number

        System.out.print("Operator: ");
        String operator = input.next().strip();//gets and stores operator

        switch(operator.charAt(0)){//compares the operator input with corresponding operator to do the math
            case '+'://in case of +, set total to numberOne plus numberTwo
                total = numberOne+numberTwo;
                break;
            case '-':
                total = numberOne-numberTwo;
                break;
            case '*':
                total = numberOne*numberTwo;
                break;
            case '/':
                if(numberTwo == 0 ){ //tests to see if there's division by zero
                    error = true;
                    break;
                }else{
                    total = numberOne/numberTwo;
                    break;
                }
        }//end switch

        if(error==true){//if error is true return this
            System.out.println("Error: Division by Zero");
        }else{//else, return numberOne + numberTwo = total
            System.out.println(numberOne + " " + operator + " " + numberTwo + " = " + total);
        }//end of if else

    }//end of main
}//end of class
