import java.util.Scanner;
//note: streams would be really helpful for this problem, but I don't know much about it yet
//code is a bit clunky. could probably use better code or make a method to remove duplicate code

public class Problem3 {

    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int a = 0;
        int e = 0;
        int i = 0;
        int o = 0;
        int u = 0;//stores the amount of times these appear

        String endMessage = "Vowel(s) not present:";//variable that is printed out later

        boolean missingVowels = true;

        System.out.print("Message: ");
        String messageInput = input.nextLine();//takes the user input

        for(int j = 0; j<messageInput.length(); j++){//compare every letter of the input
            switch(messageInput.toLowerCase().charAt(j)){//compare every letter by taking one char at a time(lowercased so uppercased letters can be counted
                case 'a':
                    a+=1;
                    break;
                case 'e':
                    e+=1;
                    break;
                case 'i':
                    i+=1;
                    break;
                case 'o':
                    o+=1;
                    break;
                case 'u':
                    u+=1;
                    break;
            }//end of switch
        }//end of for
        System.out.println("Number of vowels: " + (a+e+i+o+u));//end statement
        if(a==0){
            endMessage += " a";
            missingVowels = true;
        }
        if(e==0){
            endMessage += " e";
            missingVowels = true;
        }
        if(i==0){
            endMessage +=" i";
            missingVowels = true;
        }
        if(o==0){
            endMessage+= " o";
            missingVowels = true;
        }
        if(u==0){
            endMessage+= " u";
            missingVowels = true;
        }//bunch of clunky if statements that adds missing letter to the endmessage string. sets missing vowels to true if there are missing vowels
        if(missingVowels == true){//if missingvowels is true, do this
            System.out.println(endMessage);
        }
    }
}
