import java.util.*;
import java.util.stream.Collectors;//stream stuff

public class Problem4 {
    public static void main(String[] args) {

        Scanner doggo = new Scanner(System.in).useDelimiter("\\n");//btw, you can name the scanner anything, not just input
        //delimiter separates the input by \\n which is a code way to say space
        List<String> names = new ArrayList<String>();//array to store names
        String input;//string that stores user input
        String bestStudent = "";//string that stores the names of students with best attendance
        int mostAttend = 0;//integer that stores the most attendance

        System.out.print("Number of Weeks: ");
        int numWeeks = Integer.parseInt(doggo.nextLine());//takes the number of weeks inputted

        for(int i = 0; i < numWeeks; i++){//run this for each week
            System.out.print("Week " + (i+1) + " Attendance: ");
            input = doggo.nextLine();//stores input
            Scanner sort = new Scanner(input);//scanner that sorts by space/delimiter \\n
            int inputName = 1;//set number of names in input to one

            for(int j = 0; j < input.strip().length(); j++){
                if(input.charAt(j)==' '){//count each space between names
                    inputName++;//increase counter for number of names
                }//end if
            }//end for

            for(int k = 0; k < inputName; k++){//for each name
                String test = sort.next();//get a name after a space
                names.add(test);//add it to the arraylist
               // System.out.println(test);//test code to make sure this code works

            }//end for that adds to list

        }//end for (week version)
        List<String> distinctNames = names.stream().distinct().collect(Collectors.toList());//turns the values in names to a stream of data that is distincted(removes duplicates) and collects them and stored in distinctNames list

        for(String here: distinctNames){//code to figure out the most attendance
            int most;
            most = Collections.frequency(names, here);
            if(most>=mostAttend){
                mostAttend=most;
                //System.out.println(mostAttend);//test code
            }
            //System.out.println(here); //more test code
        }
        for(String hereTwo : distinctNames){//code to figure out the students with most attendance
            int currentMost;
            currentMost = Collections.frequency(names,hereTwo);
            if(currentMost == mostAttend){
                bestStudent += " " + hereTwo;
            }
        }

      System.out.println("Best Attendance:"+ bestStudent + ", " + mostAttend + " meetings");//answer
    }//end of main

}//end of class
