import java.text.DecimalFormat;//format decimal to two places
import java.util.Scanner;//user input
import java.text.NumberFormat;//wait, what is this. oh, it works with decimal format to format text

public class Problem2 {

    public static void main(String[] args){

        Scanner input = new Scanner(System.in);//new scanner
        double balance = 0; //account balance
        double transaction = 0; //transaction
        NumberFormat format = new DecimalFormat("#0.00");//format

        do {//do all of this...
            System.out.print("Transaction: ");
            transaction = Double.parseDouble(input.next());//takes user input and converts from string to double
            balance += transaction;//adds transaction to balance

            if(balance<0&&transaction!=0){//if less than 0, do this. !=0 is there to make sure this doesn't run when user closes code
                System.out.println("ALERT: Your account has a negative balance of $" + format.format(balance) + "!");
            }else if(balance<250&&transaction!=0){
                System.out.println("WARNING: Your balance of $" + format.format(balance) + " is less than $250.");
            }
        }while(transaction!=0);//... while user input is not 0

        System.out.println("Your final balance is $" + format.format(balance) + ".");//final output

    }//end main
}//end class
